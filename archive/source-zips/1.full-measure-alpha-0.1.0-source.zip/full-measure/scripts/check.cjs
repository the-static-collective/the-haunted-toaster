const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");

const root = path.resolve(__dirname, "..");
const required = [
  "package.json",
  "README.md",
  "src/main.cjs",
  "src/preload.cjs",
  "src/render/analyze.cjs",
  "src/render/render.cjs",
  "src/renderer/index.html",
  "src/renderer/styles.css",
  "src/renderer/app.js",
];

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    if (["node_modules", "release", "test-artifacts"].includes(entry.name)) {
      return [];
    }
    const fullPath = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(fullPath) : [fullPath];
  });
}

for (const relativePath of required) {
  if (!fs.existsSync(path.join(root, relativePath))) {
    throw new Error(`Missing required alpha file: ${relativePath}`);
  }
}

const scripts = walk(root).filter((filePath) => /\.(?:cjs|js)$/.test(filePath));
for (const filePath of scripts) {
  const result = spawnSync(process.execPath, ["--check", filePath], {
    encoding: "utf8",
  });
  if (result.status !== 0) {
    process.stderr.write(result.stderr);
    process.exit(result.status || 1);
  }
}

const html = fs.readFileSync(
  path.join(root, "src", "renderer", "index.html"),
  "utf8",
);
for (const reference of ["./styles.css", "./app.js"]) {
  if (!html.includes(reference)) {
    throw new Error(`Renderer HTML is missing ${reference}`);
  }
}

console.log(`Full Measure check passed (${scripts.length} scripts).`);

