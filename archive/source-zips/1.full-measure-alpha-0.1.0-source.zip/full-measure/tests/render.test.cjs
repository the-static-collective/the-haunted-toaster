const test = require("node:test");
const assert = require("node:assert/strict");
const {
  audioPlan,
  cleanText,
  normalizeLyrics,
} = require("../src/render/render.cjs");

test("copies MP3 and AAC streams but protects portable WAV output", () => {
  assert.equal(audioPlan("mp3").mode, "stream-copy");
  assert.equal(audioPlan("aac").mode, "stream-copy");
  assert.equal(audioPlan("pcm_s16le").mode, "high-quality-container-encode");
  assert.deepEqual(audioPlan("pcm_s16le").ffmpegArgs, [
    "-c:a",
    "aac",
    "-b:a",
    "320k",
  ]);
});

test("keeps lyric content while omitting section headings", () => {
  const lines = normalizeLyrics(`
    [Verse 1]
    The spoon remembers

    [Chorus]
    The porch light stays
    [not a heading because this bracket is deliberately far too long to be treated as one]
  `);

  assert.deepEqual(lines, [
    "The spoon remembers",
    "The porch light stays",
    "[not a heading because this bracket is deliberately far too long to be treated as one]",
  ]);
});

test("removes null bytes and obeys a hard text boundary", () => {
  assert.equal(cleanText("  hello\0 world  "), "hello world");
  assert.equal(cleanText("abcdef", 4), "abcd");
});

