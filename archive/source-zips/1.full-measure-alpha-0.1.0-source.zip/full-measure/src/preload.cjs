const { contextBridge, ipcRenderer, webUtils } = require("electron");

function subscribe(channel, callback) {
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld("fullMeasure", {
  chooseAudio: () => ipcRenderer.invoke("dialog:choose-audio"),
  chooseImage: () => ipcRenderer.invoke("dialog:choose-image"),
  chooseOutput: (suggestedName) =>
    ipcRenderer.invoke("dialog:choose-output", suggestedName),
  inspectAudio: (filePath) => ipcRenderer.invoke("media:inspect", filePath),
  startRender: (config) => ipcRenderer.invoke("render:start", config),
  cancelRender: () => ipcRenderer.invoke("render:cancel"),
  revealFile: (filePath) => ipcRenderer.invoke("shell:reveal", filePath),
  openFile: (filePath) => ipcRenderer.invoke("shell:open", filePath),
  getVersion: () => ipcRenderer.invoke("app:version"),
  pathForFile: (file) => webUtils.getPathForFile(file),
  onProgress: (callback) => subscribe("render:progress", callback),
  onPhase: (callback) => subscribe("render:phase", callback),
});

