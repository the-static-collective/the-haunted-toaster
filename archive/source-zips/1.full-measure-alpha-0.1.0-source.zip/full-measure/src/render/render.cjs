const fs = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");
const { createProceduralPpm } = require("./artwork.cjs");
const { inspectAudio, probeMedia } = require("./analyze.cjs");
const { getPreset } = require("./presets.cjs");
const { hashFile, writeReceipt } = require("./receipt.cjs");
const { resolveFfmpeg, runProcess } = require("./tooling.cjs");

const COPYABLE_MP4_AUDIO = new Set(["aac", "mp3", "alac", "ac3", "eac3"]);

function cleanText(value, maxLength = 8_000) {
  return String(value || "")
    .replace(/\0/g, "")
    .replace(/\r\n?/g, "\n")
    .trim()
    .slice(0, maxLength);
}

function normalizeLyrics(lyrics) {
  return cleanText(lyrics)
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line && !/^\[[^\]]{1,48}\]$/.test(line))
    .slice(0, 64);
}

function audioPlan(codec) {
  if (COPYABLE_MP4_AUDIO.has(codec)) {
    return {
      mode: "stream-copy",
      codec,
      ffmpegArgs: ["-c:a", "copy"],
      statement:
        "The source audio stream was copied into the MP4 without re-encoding.",
    };
  }

  return {
    mode: "high-quality-container-encode",
    codec: "aac",
    ffmpegArgs: ["-c:a", "aac", "-b:a", "320k"],
    statement:
      "The source performance and timing were preserved; the audio was encoded to 320 kbps AAC for portable MP4 playback.",
  };
}

function phaseHue(section, index, preset) {
  const energyShift = (section.energy - 0.5) * 18;
  const alternating = index % 2 === 0 ? -3 : 4;
  return Number((energyShift + alternating + preset.hueDrift * 0.3).toFixed(2));
}

function textAlpha(start, end) {
  const fade = Math.min(0.45, Math.max(0.16, (end - start) * 0.12));
  return `if(lt(t\\,${(start + fade).toFixed(3)})\\,(t-${start.toFixed(
    3,
  )})/${fade.toFixed(3)}\\,if(gt(t\\,${(end - fade).toFixed(
    3,
  )})\\,(${end.toFixed(3)}-t)/${fade.toFixed(3)}\\,1))`;
}

async function writeTextFile(tempDirectory, name, value) {
  const fileName = `${name}.txt`;
  await fs.writeFile(
    path.join(tempDirectory, fileName),
    `${cleanText(value, 1_000)}\n`,
    "utf8",
  );
  return fileName;
}

async function buildFilterGraph({
  tempDirectory,
  analysis,
  preset,
  title,
  artist,
  lyrics,
  hasImage,
  width,
  height,
  fps,
}) {
  const filters = [];
  const waveHeight = Math.max(180, Math.round(height * 0.235));
  const waveY = height - waveHeight - Math.round(height * 0.07);

  filters.push(
    `[0:a]asplit=2[waveAudio][auraAudio]`,
    `[waveAudio]showwaves=s=${width}x${waveHeight}:mode=cline:rate=${fps}:colors=${preset.waveColors.join(
      "|",
    )}:scale=sqrt,format=rgba,colorkey=black:0.08:0.0,colorchannelmixer=aa=0.78[wave]`,
    `[wave]pad=${width}:${height}:0:${waveY}:color=black@0.0[waveFull]`,
    `[auraAudio]showwaves=s=${width}x${height}:mode=cline:rate=${fps}:colors=0xFFFFFF:scale=cbrt,format=rgba,colorkey=black:0.08:0.0,colorchannelmixer=aa=0.10[aura]`,
    `[1:v]noise=alls=${Math.max(
      2,
      Math.round(preset.grain * 0.55),
    )}:allf=t+u,scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},zoompan=z='1.035+0.018*sin(on/150)':x='iw/2-(iw/zoom/2)+sin(on/210)*iw*0.012':y='ih/2-(ih/zoom/2)+cos(on/185)*ih*0.012':d=1:s=${width}x${height}:fps=${fps},format=rgba[procedural]`,
  );

  let baseLabel = "procedural";
  if (hasImage) {
    filters.push(
      `[2:v]scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},zoompan=z='1.025+0.022*sin(on/175)':x='iw/2-(iw/zoom/2)+cos(on/230)*iw*0.014':y='ih/2-(ih/zoom/2)+sin(on/205)*ih*0.014':d=1:s=${width}x${height}:fps=${fps},format=rgba[photo]`,
      `[procedural][photo]blend=all_mode=${preset.blendMode}:all_opacity=${preset.imageOpacity}[baseImage]`,
    );
    baseLabel = "baseImage";
  }

  filters.push(
    `[${baseLabel}]hue=h='${preset.hueDrift}*sin(t*0.045)':s=1.06[drift0]`,
  );

  let phaseLabel = "drift0";
  analysis.sections.forEach((section, index) => {
    const nextLabel = `phase${index + 1}`;
    const hue = phaseHue(section, index, preset);
    filters.push(
      `[${phaseLabel}]hue=h=${hue}:enable='between(t,${section.start.toFixed(
        3,
      )},${section.end.toFixed(3)})'[${nextLabel}]`,
    );
    phaseLabel = nextLabel;
  });

  filters.push(
    `[${phaseLabel}]format=rgba[phaseRgba]`,
    `[phaseRgba][aura]overlay=0:0:shortest=1[spectral]`,
    `[spectral][waveFull]overlay=0:0:shortest=1[stage0]`,
  );

  let textLabel = "stage0";
  const titleFile = await writeTextFile(
    tempDirectory,
    "title",
    title || path.parse(analysis.filename).name,
  );
  filters.push(
    `[${textLabel}]drawtext=textfile='${titleFile}':expansion=none:fontcolor=white:fontsize=${Math.round(
      height * 0.044,
    )}:x=${Math.round(width * 0.047)}:y=${Math.round(
      height * 0.072,
    )}:shadowcolor=black@0.58:shadowx=2:shadowy=2:alpha='${textAlpha(
      0,
      Math.min(7, analysis.duration),
    )}':enable='between(t,0,${Math.min(7, analysis.duration).toFixed(
      3,
    )})'[titleStage]`,
  );
  textLabel = "titleStage";

  if (artist) {
    const artistFile = await writeTextFile(tempDirectory, "artist", artist);
    filters.push(
      `[${textLabel}]drawtext=textfile='${artistFile}':expansion=none:fontcolor=white@0.76:fontsize=${Math.round(
        height * 0.021,
      )}:x=${Math.round(width * 0.048)}:y=${Math.round(
        height * 0.13,
      )}:shadowcolor=black@0.6:shadowx=1:shadowy=1:alpha='${textAlpha(
        0.5,
        Math.min(7, analysis.duration),
      )}':enable='between(t,0.5,${Math.min(7, analysis.duration).toFixed(
        3,
      )})'[artistStage]`,
    );
    textLabel = "artistStage";
  }

  const lyricLines = normalizeLyrics(lyrics);
  if (lyricLines.length) {
    const availableStart = Math.min(6.5, analysis.duration * 0.08);
    const availableEnd = Math.max(
      availableStart + 0.5,
      analysis.duration - Math.min(4.5, analysis.duration * 0.055),
    );
    const slot = (availableEnd - availableStart) / lyricLines.length;

    for (let index = 0; index < lyricLines.length; index += 1) {
      const line = lyricLines[index];
      const start = availableStart + slot * index;
      const end = Math.min(
        availableEnd,
        start + Math.max(0.45, slot * 0.9),
      );
      const lineFile = await writeTextFile(
        tempDirectory,
        `lyric-${String(index).padStart(3, "0")}`,
        line,
      );
      const nextLabel = `lyricStage${index}`;
      const fontSize = Math.round(
        height * (line.length > 64 ? 0.031 : line.length > 42 ? 0.037 : 0.043),
      );
      filters.push(
        `[${textLabel}]drawtext=textfile='${lineFile}':expansion=none:fontcolor=white:fontsize=${fontSize}:x=(w-text_w)/2:y=h*0.62:box=1:boxcolor=black@0.26:boxborderw=${Math.round(
          height * 0.014,
        )}:shadowcolor=black@0.75:shadowx=2:shadowy=2:alpha='${textAlpha(
          start,
          end,
        )}':enable='between(t,${start.toFixed(3)},${end.toFixed(
          3,
        )})'[${nextLabel}]`,
      );
      textLabel = nextLabel;
    }
  }

  const markFile = await writeTextFile(
    tempDirectory,
    "mark",
    "FULL MEASURE  //  VIDEO RECEIPT",
  );
  filters.push(
    `[${textLabel}]drawtext=textfile='${markFile}':expansion=none:fontcolor=white@0.48:fontsize=${Math.round(
      height * 0.014,
    )}:x=w-text_w-${Math.round(width * 0.026)}:y=h-text_h-${Math.round(
      height * 0.026,
    )},format=yuv420p[vout]`,
  );

  return {
    graph: filters.join(";\n"),
    lyricLines,
  };
}

async function safeUnlink(filePath) {
  try {
    await fs.unlink(filePath);
  } catch {
    // An absent or locked partial file needs no further cleanup attempt.
  }
}

async function probeRenderedOutput(filePath, attempts = 4) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      return await probeMedia(filePath);
    } catch (error) {
      lastError = error;
      if (attempt < attempts - 1) {
        await new Promise((resolve) =>
          setTimeout(resolve, 180 * (attempt + 1)),
        );
      }
    }
  }
  throw lastError;
}

async function renderVideo(config, hooks = {}) {
  const audioPath = path.resolve(config.audioPath);
  const outputPath = path.resolve(config.outputPath);
  const imagePath = config.imagePath ? path.resolve(config.imagePath) : null;
  const width = Number(config.width) || 1920;
  const height = Number(config.height) || 1080;
  const fps = Number(config.fps) || 30;
  const preset = getPreset(config.presetId);
  const title = cleanText(config.title, 160);
  const artist = cleanText(config.artist, 160);
  const lyrics = cleanText(config.lyrics, 24_000);
  const signal = hooks.signal;

  if (path.extname(outputPath).toLowerCase() !== ".mp4") {
    throw new Error("Full Measure currently renders MP4 files.");
  }

  const [audioStat, imageStat] = await Promise.all([
    fs.stat(audioPath),
    imagePath ? fs.stat(imagePath) : Promise.resolve(null),
  ]);
  if (!audioStat.isFile()) throw new Error("The selected song is not a file.");
  if (imageStat && !imageStat.isFile()) {
    throw new Error("The selected image is not a file.");
  }

  await fs.mkdir(path.dirname(outputPath), { recursive: true });
  const tempDirectory = await fs.mkdtemp(
    path.join(os.tmpdir(), "full-measure-"),
  );
  const jobId = crypto.randomUUID();
  const startedAt = new Date();

  try {
    hooks.onPhase?.("analysis", "Listening for the song's shape…");
    const analysis = config.analysis || (await inspectAudio(audioPath));
    if (!analysis.audio) throw new Error("No audio stream was found.");

    const sourceHash = await hashFile(audioPath);
    const proceduralPath = path.join(tempDirectory, "garment.ppm");
    await createProceduralPpm(proceduralPath, preset);

    hooks.onPhase?.("weaving", "Weaving the visual garment…");
    const filter = await buildFilterGraph({
      tempDirectory,
      analysis,
      preset,
      title,
      artist,
      lyrics,
      hasImage: Boolean(imagePath),
      width,
      height,
      fps,
    });
    const filterPath = path.join(tempDirectory, "render.ffgraph");
    await fs.writeFile(filterPath, `${filter.graph}\n`, "utf8");

    const sourceAudioPlan = audioPlan(analysis.audio.codec);
    const ffmpegArgs = [
      "-y",
      "-hide_banner",
      "-nostdin",
      "-i",
      audioPath,
      "-loop",
      "1",
      "-framerate",
      String(fps),
      "-i",
      proceduralPath,
    ];

    if (imagePath) {
      ffmpegArgs.push(
        "-loop",
        "1",
        "-framerate",
        String(fps),
        "-i",
        imagePath,
      );
    }

    ffmpegArgs.push(
      "-filter_complex_script",
      filterPath,
      "-map",
      "[vout]",
      "-map",
      "0:a:0",
      "-c:v",
      "libx264",
      "-preset",
      config.encoderPreset || "medium",
      "-crf",
      String(config.crf || 19),
      "-profile:v",
      "high",
      "-level",
      "4.2",
      "-pix_fmt",
      "yuv420p",
      ...sourceAudioPlan.ffmpegArgs,
      "-movflags",
      "+faststart",
      "-shortest",
      "-max_interleave_delta",
      "0",
      "-progress",
      "pipe:1",
      "-stats_period",
      "0.5",
      outputPath,
    );

    hooks.onPhase?.("rendering", "Rendering the full measure…");
    let progressBuffer = "";
    await runProcess(resolveFfmpeg(), ffmpegArgs, {
      cwd: tempDirectory,
      signal,
      collectStdout: false,
      onStdout(chunk) {
        progressBuffer += chunk;
        const lines = progressBuffer.split(/\r?\n/);
        progressBuffer = lines.pop() || "";
        for (const line of lines) {
          const match = line.match(/^out_time_(?:us|ms)=(\d+)$/);
          if (!match) continue;
          const renderedSeconds = Number(match[1]) / 1_000_000;
          const ratio = Math.max(
            0,
            Math.min(0.995, renderedSeconds / analysis.duration),
          );
          hooks.onProgress?.({
            ratio,
            renderedSeconds,
            duration: analysis.duration,
          });
        }
      },
    });

    hooks.onPhase?.("validating", "Reading the finished receipt…");
    const outputMedia = await probeRenderedOutput(outputPath);
    if (!outputMedia.video || !outputMedia.audio) {
      throw new Error("The rendered file is missing a video or audio stream.");
    }

    const durationDeltaMs = Math.round(
      Math.abs(outputMedia.duration - analysis.duration) * 1_000,
    );
    if (durationDeltaMs > 250) {
      throw new Error(
        `The output differs from the song by ${durationDeltaMs} ms; the render was not accepted.`,
      );
    }

    const outputHash = await hashFile(outputPath);
    const finishedAt = new Date();
    const receipt = {
      schema: "full-measure.video-receipt.v1",
      receiptId: jobId,
      product: "Full Measure",
      artifact: "Video Receipt",
      createdAt: finishedAt.toISOString(),
      source: {
        filename: analysis.filename,
        sha256: sourceHash,
        sizeBytes: analysis.sizeBytes,
        durationSeconds: analysis.duration,
        format: analysis.formatName,
        audio: analysis.audio,
      },
      treatment: {
        title: title || path.parse(analysis.filename).name,
        artist: artist || null,
        garment: {
          id: preset.id,
          name: preset.name,
        },
        userImage: imagePath ? path.basename(imagePath) : null,
        wordsIncluded: filter.lyricLines.length > 0,
        wordLineCount: filter.lyricLines.length,
        wordTiming: filter.lyricLines.length
          ? "evenly-distributed-alpha-cues"
          : null,
        sections: analysis.sections.map((section) => ({
          index: section.index,
          label: section.label,
          startSeconds: Number(section.start.toFixed(3)),
          endSeconds: Number(section.end.toFixed(3)),
          energy: Number(section.energy.toFixed(4)),
        })),
      },
      render: {
        width,
        height,
        framesPerSecond: fps,
        videoCodec: outputMedia.video.codec,
        pixelFormat: outputMedia.video.pixelFormat,
        sourceAudioHandling: {
          mode: sourceAudioPlan.mode,
          codec: sourceAudioPlan.codec,
          statement: sourceAudioPlan.statement,
        },
        startedAt: startedAt.toISOString(),
        finishedAt: finishedAt.toISOString(),
        elapsedSeconds: Number(
          ((finishedAt.getTime() - startedAt.getTime()) / 1_000).toFixed(3),
        ),
      },
      output: {
        filename: path.basename(outputPath),
        sha256: outputHash,
        sizeBytes: outputMedia.sizeBytes,
        durationSeconds: outputMedia.duration,
        video: outputMedia.video,
        audio: outputMedia.audio,
      },
      validation: {
        playableStreamsPresent: true,
        fullTimelineCovered: true,
        continuousFilterGraph: true,
        sourceDurationSeconds: analysis.duration,
        outputDurationSeconds: outputMedia.duration,
        durationDeltaMilliseconds: durationDeltaMs,
        accepted: true,
      },
    };

    const receiptPath = await writeReceipt(receipt, outputPath);
    hooks.onProgress?.({
      ratio: 1,
      renderedSeconds: analysis.duration,
      duration: analysis.duration,
    });

    return {
      jobId,
      outputPath,
      receiptPath,
      receipt,
      analysis,
    };
  } catch (error) {
    await safeUnlink(outputPath);
    throw error;
  } finally {
    await fs.rm(tempDirectory, { recursive: true, force: true });
  }
}

module.exports = {
  COPYABLE_MP4_AUDIO,
  audioPlan,
  buildFilterGraph,
  cleanText,
  normalizeLyrics,
  renderVideo,
};
