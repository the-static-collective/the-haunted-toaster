const path = require("node:path");
const fs = require("node:fs/promises");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  shell,
} = require("electron");
const { inspectAudio } = require("./render/analyze.cjs");
const { renderVideo } = require("./render/render.cjs");

const AUDIO_EXTENSIONS = new Set([".mp3", ".wav", ".m4a", ".aac", ".flac"]);
const IMAGE_EXTENSIONS = new Set([
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".bmp",
  ".tif",
  ".tiff",
]);

let mainWindow = null;
let activeRender = null;

function safeBaseName(value) {
  return String(value || "full-measure")
    .normalize("NFKD")
    .replace(/[^\w\s.-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 96);
}

async function assertLocalFile(filePath, allowedExtensions, label) {
  if (!filePath || typeof filePath !== "string") {
    throw new Error(`Choose a ${label} first.`);
  }
  const resolved = path.resolve(filePath);
  if (!allowedExtensions.has(path.extname(resolved).toLowerCase())) {
    throw new Error(`That ${label} format is not supported in this alpha.`);
  }
  const stat = await fs.stat(resolved);
  if (!stat.isFile()) throw new Error(`The selected ${label} is not a file.`);
  return resolved;
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1080,
    minHeight: 720,
    backgroundColor: "#09080b",
    title: "Full Measure",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.once("ready-to-show", () => mainWindow?.show());
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

function registerIpc() {
  ipcMain.handle("dialog:choose-audio", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "Choose the finished song",
      properties: ["openFile"],
      filters: [
        {
          name: "Audio",
          extensions: ["mp3", "wav", "m4a", "aac", "flac"],
        },
      ],
    });
    return result.canceled ? null : result.filePaths[0];
  });

  ipcMain.handle("dialog:choose-image", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "Choose an optional image",
      properties: ["openFile"],
      filters: [
        {
          name: "Images",
          extensions: ["png", "jpg", "jpeg", "webp", "bmp", "tif", "tiff"],
        },
      ],
    });
    return result.canceled ? null : result.filePaths[0];
  });

  ipcMain.handle("dialog:choose-output", async (_event, suggestedName) => {
    const videosDirectory = app.getPath("videos");
    const result = await dialog.showSaveDialog(mainWindow, {
      title: "Save the full music video",
      defaultPath: path.join(
        videosDirectory,
        `${safeBaseName(suggestedName) || "full-measure"}.mp4`,
      ),
      filters: [{ name: "MP4 video", extensions: ["mp4"] }],
      properties: ["createDirectory", "showOverwriteConfirmation"],
    });
    return result.canceled ? null : result.filePath;
  });

  ipcMain.handle("media:inspect", async (_event, filePath) => {
    const audioPath = await assertLocalFile(
      filePath,
      AUDIO_EXTENSIONS,
      "song",
    );
    return inspectAudio(audioPath);
  });

  ipcMain.handle("render:start", async (event, config) => {
    if (activeRender) {
      throw new Error("A render is already in progress.");
    }

    const audioPath = await assertLocalFile(
      config.audioPath,
      AUDIO_EXTENSIONS,
      "song",
    );
    const imagePath = config.imagePath
      ? await assertLocalFile(config.imagePath, IMAGE_EXTENSIONS, "image")
      : null;
    const outputPath = path.resolve(config.outputPath);
    const controller = new AbortController();
    activeRender = controller;

    try {
      return await renderVideo(
        {
          ...config,
          audioPath,
          imagePath,
          outputPath,
        },
        {
          signal: controller.signal,
          onPhase(phase, message) {
            if (!event.sender.isDestroyed()) {
              event.sender.send("render:phase", { phase, message });
            }
          },
          onProgress(progress) {
            if (!event.sender.isDestroyed()) {
              event.sender.send("render:progress", progress);
            }
          },
        },
      );
    } finally {
      activeRender = null;
    }
  });

  ipcMain.handle("render:cancel", () => {
    if (!activeRender) return false;
    activeRender.abort();
    return true;
  });

  ipcMain.handle("shell:reveal", async (_event, filePath) => {
    shell.showItemInFolder(path.resolve(filePath));
    return true;
  });

  ipcMain.handle("shell:open", async (_event, filePath) => {
    const error = await shell.openPath(path.resolve(filePath));
    if (error) throw new Error(error);
    return true;
  });

  ipcMain.handle("app:version", () => app.getVersion());
}

app.whenReady().then(() => {
  if (process.platform === "win32") {
    app.setAppUserModelId("org.staticcollective.fullmeasure");
  }
  registerIpc();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => {
  activeRender?.abort();
});

