(() => {
  const api = window.fullMeasure;
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const state = {
    audioPath: null,
    audio: null,
    imagePath: null,
    presetId: "porchlight",
    presetName: "Porchlight",
    rendering: false,
    result: null,
  };

  const elements = {
    audioDrop: $("#audioDrop"),
    audioDropTitle: $("#audioDropTitle"),
    audioDropHint: $("#audioDropHint"),
    audioChooseChip: $("#audioChooseChip"),
    songFacts: $("#songFacts"),
    durationFact: $("#durationFact"),
    codecFact: $("#codecFact"),
    sectionFact: $("#sectionFact"),
    imageDrop: $("#imageDrop"),
    imageDropTitle: $("#imageDropTitle"),
    imageDropHint: $("#imageDropHint"),
    imageAction: $("#imageAction"),
    removeImage: $("#removeImage"),
    titleInput: $("#titleInput"),
    artistInput: $("#artistInput"),
    lyricsInput: $("#lyricsInput"),
    wordLineCount: $("#wordLineCount"),
    shapeState: $("#shapeState"),
    timeline: $("#timeline"),
    sectionLegend: $("#sectionLegend"),
    slateDuration: $("#slateDuration"),
    slatePicture: $("#slatePicture"),
    slateGarment: $("#slateGarment"),
    slateAudio: $("#slateAudio"),
    progressCard: $("#progressCard"),
    phaseMessage: $("#phaseMessage"),
    progressPercent: $("#progressPercent"),
    progressFill: $("#progressFill"),
    progressTime: $("#progressTime"),
    resultCard: $("#resultCard"),
    resultName: $("#resultName"),
    resultProof: $("#resultProof"),
    openResult: $("#openResult"),
    revealResult: $("#revealResult"),
    errorCard: $("#errorCard"),
    errorMessage: $("#errorMessage"),
    renderButton: $("#renderButton"),
    cancelButton: $("#cancelButton"),
    versionLabel: $("#versionLabel"),
  };

  function basename(filePath) {
    return String(filePath || "").split(/[\\/]/).pop() || "";
  }

  function stem(filePath) {
    const name = basename(filePath);
    const dot = name.lastIndexOf(".");
    return dot > 0 ? name.slice(0, dot) : name;
  }

  function formatDuration(seconds) {
    if (!Number.isFinite(Number(seconds))) return "0:00";
    const total = Math.max(0, Math.round(Number(seconds)));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const remainder = total % 60;
    if (hours) {
      return `${hours}:${String(minutes).padStart(2, "0")}:${String(
        remainder,
      ).padStart(2, "0")}`;
    }
    return `${minutes}:${String(remainder).padStart(2, "0")}`;
  }

  function formatBytes(bytes) {
    const value = Number(bytes);
    if (!Number.isFinite(value) || value <= 0) return "unknown size";
    const units = ["B", "KB", "MB", "GB"];
    const index = Math.min(
      units.length - 1,
      Math.floor(Math.log(value) / Math.log(1024)),
    );
    return `${(value / 1024 ** index).toFixed(index > 1 ? 1 : 0)} ${
      units[index]
    }`;
  }

  function usableLyricLines(value) {
    return String(value || "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !/^\[[^\]]{1,48}\]$/.test(line))
      .slice(0, 64);
  }

  function setError(error) {
    const message =
      typeof error === "string"
        ? error
        : error?.message || "An unknown render error occurred.";
    elements.errorMessage.textContent = message;
    elements.errorCard.classList.remove("is-hidden");
  }

  function clearError() {
    elements.errorCard.classList.add("is-hidden");
    elements.errorMessage.textContent = "";
  }

  function setRenderState(rendering) {
    state.rendering = rendering;
    elements.audioDrop.disabled = rendering;
    elements.imageDrop.disabled = rendering;
    elements.renderButton.disabled = rendering || !state.audio;
    elements.renderButton.classList.toggle("is-hidden", rendering);
    elements.cancelButton.classList.toggle("is-hidden", !rendering);
    if (rendering) {
      elements.progressCard.classList.remove("is-hidden");
      elements.resultCard.classList.add("is-hidden");
      elements.progressPercent.textContent = "0%";
      elements.progressFill.style.width = "0%";
      elements.phaseMessage.textContent = "Preparing the instrument…";
      elements.progressTime.textContent = `0:00 of ${formatDuration(
        state.audio?.duration,
      )}`;
    }
  }

  function renderTimeline() {
    elements.timeline.replaceChildren();
    if (!state.audio?.sections?.length) {
      elements.timeline.className = "timeline empty";
      elements.timeline.append(document.createElement("span"));
      elements.shapeState.textContent = "Waiting for a song";
      elements.sectionLegend.textContent =
        "The visual phases will change at musical energy boundaries.";
      return;
    }

    elements.timeline.className = "timeline";
    const labels = [];
    for (const section of state.audio.sections) {
      const segment = document.createElement("span");
      segment.className = "timeline-segment";
      segment.style.flexGrow = Math.max(0.1, section.end - section.start);
      segment.style.setProperty(
        "--energy",
        Math.max(0, Math.min(1, section.energy)).toFixed(3),
      );
      segment.title = `${section.label} · ${formatDuration(
        section.start,
      )}–${formatDuration(section.end)}`;
      elements.timeline.append(segment);
      labels.push(section.label);
    }
    elements.shapeState.textContent = `${state.audio.sections.length} phases`;
    elements.sectionLegend.textContent = labels.join("  ·  ");
  }

  function refreshSlate() {
    if (state.audio) {
      elements.slateDuration.textContent = `${formatDuration(
        state.audio.duration,
      )} · full song`;
      elements.slateAudio.textContent = ["aac", "mp3", "alac"].includes(
        state.audio.audio?.codec,
      )
        ? "Original stream · copied"
        : "Original master · 320k AAC";
    } else {
      elements.slateDuration.textContent = "Waiting";
      elements.slateAudio.textContent = "Original master";
    }
    elements.slatePicture.textContent = state.imagePath
      ? "Image + procedural"
      : "Procedural";
    elements.slateGarment.textContent = state.presetName;
    elements.renderButton.disabled = state.rendering || !state.audio;
  }

  async function loadAudio(filePath) {
    if (!filePath || state.rendering) return;
    clearError();
    elements.audioDrop.classList.add("is-loading");
    elements.audioDropTitle.textContent = "Listening…";
    elements.audioDropHint.textContent = "Finding sections and energy changes";
    elements.audioChooseChip.textContent = "Analyzing";

    try {
      const audio = await api.inspectAudio(filePath);
      state.audioPath = filePath;
      state.audio = audio;
      state.result = null;

      elements.audioDrop.classList.add("has-file");
      elements.audioDropTitle.textContent = audio.filename;
      elements.audioDropHint.textContent = `${formatBytes(
        audio.sizeBytes,
      )} · ${audio.audio.sampleRate / 1000} kHz · ${
        audio.audio.channels
      } channel${audio.audio.channels === 1 ? "" : "s"}`;
      elements.audioChooseChip.textContent = "Replace";
      elements.songFacts.classList.remove("is-hidden");
      elements.durationFact.textContent = formatDuration(audio.duration);
      elements.codecFact.textContent = audio.audio.codec.toUpperCase();
      elements.sectionFact.textContent = `${audio.sections.length} phases`;
      elements.resultCard.classList.add("is-hidden");
      if (!elements.titleInput.value.trim()) {
        elements.titleInput.placeholder = stem(audio.filename);
      }
      renderTimeline();
      refreshSlate();
    } catch (error) {
      state.audioPath = null;
      state.audio = null;
      elements.audioDrop.classList.remove("has-file");
      elements.audioDropTitle.textContent = "Drop a finished song";
      elements.audioDropHint.textContent = "MP3 or WAV · click to choose";
      elements.audioChooseChip.textContent = "Choose file";
      elements.songFacts.classList.add("is-hidden");
      renderTimeline();
      refreshSlate();
      setError(error);
    } finally {
      elements.audioDrop.classList.remove("is-loading");
    }
  }

  function loadImage(filePath) {
    if (!filePath || state.rendering) return;
    state.imagePath = filePath;
    elements.imageDropTitle.textContent = basename(filePath);
    elements.imageDropHint.textContent = "Will be woven into the garment";
    elements.imageAction.textContent = "↻";
    elements.removeImage.classList.remove("is-hidden");
    refreshSlate();
  }

  function clearImage() {
    state.imagePath = null;
    elements.imageDropTitle.textContent = "Add one image";
    elements.imageDropHint.textContent = "Optional · PNG, JPG, or WebP";
    elements.imageAction.textContent = "+";
    elements.removeImage.classList.add("is-hidden");
    refreshSlate();
  }

  async function pickAudio() {
    const filePath = await api.chooseAudio();
    if (filePath) await loadAudio(filePath);
  }

  async function pickImage() {
    const filePath = await api.chooseImage();
    if (filePath) loadImage(filePath);
  }

  function wireDropTarget(element, kind) {
    for (const eventName of ["dragenter", "dragover"]) {
      element.addEventListener(eventName, (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (!state.rendering) element.classList.add("is-dragging");
      });
    }
    for (const eventName of ["dragleave", "drop"]) {
      element.addEventListener(eventName, (event) => {
        event.preventDefault();
        event.stopPropagation();
        element.classList.remove("is-dragging");
      });
    }
    element.addEventListener("drop", async (event) => {
      if (state.rendering) return;
      const file = event.dataTransfer.files?.[0];
      if (!file) return;
      const filePath = api.pathForFile(file);
      if (!filePath) {
        setError("The dropped file path could not be read.");
        return;
      }
      if (kind === "audio") await loadAudio(filePath);
      else loadImage(filePath);
    });
  }

  async function startRender() {
    if (!state.audio || state.rendering) return;
    clearError();
    const title =
      elements.titleInput.value.trim() || stem(state.audio.filename);
    const outputPath = await api.chooseOutput(`${title}-full-measure`);
    if (!outputPath) return;

    setRenderState(true);
    try {
      const result = await api.startRender({
        audioPath: state.audioPath,
        imagePath: state.imagePath,
        outputPath,
        presetId: state.presetId,
        title: elements.titleInput.value,
        artist: elements.artistInput.value,
        lyrics: elements.lyricsInput.value,
        width: 1920,
        height: 1080,
        fps: 30,
      });
      state.result = result;
      elements.progressCard.classList.add("is-hidden");
      elements.resultCard.classList.remove("is-hidden");
      elements.resultName.textContent = basename(result.outputPath);
      elements.resultProof.textContent = `${formatBytes(
        result.receipt.output.sizeBytes,
      )} · ${result.receipt.validation.durationDeltaMilliseconds} ms duration delta · receipt verified`;
    } catch (error) {
      if (!String(error?.message || "").toLowerCase().includes("cancel")) {
        setError(error);
      }
      elements.progressCard.classList.add("is-hidden");
    } finally {
      setRenderState(false);
    }
  }

  elements.audioDrop.addEventListener("click", pickAudio);
  elements.imageDrop.addEventListener("click", pickImage);
  elements.removeImage.addEventListener("click", clearImage);
  elements.renderButton.addEventListener("click", startRender);
  elements.cancelButton.addEventListener("click", async () => {
    elements.phaseMessage.textContent = "Stopping safely…";
    await api.cancelRender();
  });
  elements.openResult.addEventListener("click", () => {
    if (state.result) api.openFile(state.result.outputPath);
  });
  elements.revealResult.addEventListener("click", () => {
    if (state.result) api.revealFile(state.result.outputPath);
  });
  elements.lyricsInput.addEventListener("input", () => {
    elements.wordLineCount.textContent = String(
      usableLyricLines(elements.lyricsInput.value).length,
    );
  });

  for (const card of $$(".garment-card")) {
    card.addEventListener("click", () => {
      if (state.rendering) return;
      for (const sibling of $$(".garment-card")) {
        sibling.classList.remove("is-selected");
        sibling.setAttribute("aria-checked", "false");
      }
      card.classList.add("is-selected");
      card.setAttribute("aria-checked", "true");
      state.presetId = card.dataset.preset;
      state.presetName = card.querySelector(".garment-copy strong").textContent;
      refreshSlate();
    });
  }

  wireDropTarget(elements.audioDrop, "audio");
  wireDropTarget(elements.imageDrop, "image");

  window.addEventListener("dragover", (event) => event.preventDefault());
  window.addEventListener("drop", (event) => event.preventDefault());

  api.onPhase(({ message }) => {
    elements.phaseMessage.textContent = message;
  });
  api.onProgress(({ ratio, renderedSeconds, duration }) => {
    const percent = Math.max(0, Math.min(100, Math.round(ratio * 100)));
    elements.progressPercent.textContent = `${percent}%`;
    elements.progressFill.style.width = `${percent}%`;
    elements.progressTime.textContent = `${formatDuration(
      renderedSeconds,
    )} of ${formatDuration(duration)}`;
  });

  api
    .getVersion()
    .then((version) => {
      elements.versionLabel.textContent = version;
    })
    .catch(() => {});

  renderTimeline();
  refreshSlate();
})();

