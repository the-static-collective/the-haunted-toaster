# Full Measure

> Drop in a song. Receive the whole damn music video.

Full Measure is a local-first desktop music-video instrument. The core renderer
does not require an account, cloud upload, subscription, or internet connection.
It turns a finished MP3 or WAV into a complete 1080p MP4, using an optional
image, a procedural visual garment, audio-reactive motion, and an optional
lightly timed words layer.

Every render also produces a **Video Receipt**: a JSON record containing source
and output hashes, media facts, detected energy sections, render settings, audio
handling, and post-render validation.

## Alpha invariant

The alpha succeeds only when this entire path succeeds:

1. Choose or drop an MP3/WAV.
2. Optionally add one image and lyrics.
3. Choose a garment.
4. Click **Make Video**.
5. Receive one playable, full-song, 1920×1080 MP4 with no blank timeline.

Generated clips and online models are not part of the critical path.

## Run

Requirements:

- Node.js 22 or newer
- npm

```bash
npm install
npm start
```

On Windows, `START_FULL_MEASURE.bat` performs that first-run setup and launches
the app. After setup, rendering itself is offline.

The install includes current platform-specific FFmpeg and FFprobe binaries. If those
cannot be resolved, Full Measure falls back to `ffmpeg` and `ffprobe` on the
system path. The environment variables `FULL_MEASURE_FFMPEG` and
`FULL_MEASURE_FFPROBE` can override either binary explicitly.

## Prove the renderer

The smoke command creates a short, multi-section audio fixture, renders the
entire file at 1080p, validates the result, and writes the MP4 plus its receipt
to `test-artifacts/`.

```bash
npm run smoke
```

Run the fast structural and unit checks with:

```bash
npm test
npm run check
```

## Audio preservation

The uploaded song remains the sole soundtrack. Full Measure never regenerates,
remixes, stretches, truncates, or adds sound.

- MP3 and AAC audio are copied byte-for-byte at the stream level into the MP4
  when the container supports it.
- WAV/PCM and FLAC must be encoded to high-quality 320 kbps AAC because
  portable MP4 playback does not reliably support those source codecs.
- Timing, pitch, channel layout, and full-song duration are preserved in both
  paths.

The Video Receipt states which path was used.

## Architecture

- `src/render/` — standalone analysis, procedural artwork, FFmpeg rendering,
  validation, and receipt code
- `src/main.cjs` — narrow Electron IPC boundary
- `src/preload.cjs` — isolated desktop bridge
- `src/renderer/` — dependency-free desktop interface
- `scripts/smoke-render.cjs` — end-to-end render proof
- `tests/` — deterministic section and receipt tests

## Current alpha boundary

The words layer distributes lyric lines across the song duration; it does not
claim phoneme-level synchronization. The next slice can add beat/onset
detection, editable cue timing, album garment reuse, and optional imported or
generated hero clips without changing the local render invariant.
