const test = require("node:test");
const assert = require("node:assert/strict");
const {
  audioPlan,
  cleanLyricProvenance,
  cleanText,
  normalizeLyrics,
} = require("../src/render/render.cjs");

test("copies MP3 and AAC streams but protects portable WAV output", () => {
  assert.equal(audioPlan("mp3").mode, "stream-copy");
  assert.equal(audioPlan("aac").mode, "stream-copy");
  assert.equal(audioPlan("pcm_s16le").mode, "high-quality-container-encode");
  assert.deepEqual(audioPlan("pcm_s16le").ffmpegArgs, [
    "-c:a",
    "aac",
    "-b:a",
    "320k",
  ]);
});

test("keeps compact lyric-sync provenance without accepting arbitrary paths", () => {
  assert.deepEqual(
    cleanLyricProvenance({
      mode: "auto-synced-local",
      engine: {
        name: "Full Measure Listener",
        whisperCppVersion: "1.9.1",
        modelId: "base.en-q5_1",
        language: "en",
      },
      alignment: {
        lineCount: 22,
        matchedCount: 22,
        reviewCount: 3,
        humanCorrectedCount: 1,
      },
      sidecarFilename: "C:\\private\\Receipt Song.lrc",
      ignoredPayload: "not part of the receipt",
    }),
    {
      mode: "auto-synced-local",
      engine: {
        name: "Full Measure Listener",
        whisperCppVersion: "1.9.1",
        modelId: "base.en-q5_1",
        language: "en",
      },
      alignment: {
        lineCount: 22,
        matchedCount: 22,
        reviewCount: 3,
        humanCorrectedCount: 1,
      },
      sidecarFilename: "Receipt Song.lrc",
    },
  );
});

test("keeps lyric content while omitting section headings", () => {
  const lines = normalizeLyrics(`
    [Verse 1]
    The spoon remembers

    [Chorus]
    The porch light stays
    [not a heading because this bracket is deliberately far too long to be treated as one]
  `);

  assert.deepEqual(lines, [
    "The spoon remembers",
    "The porch light stays",
    "[not a heading because this bracket is deliberately far too long to be treated as one]",
  ]);
});

test("removes null bytes and obeys a hard text boundary", () => {
  assert.equal(cleanText("  hello\0 world  "), "hello world");
  assert.equal(cleanText("abcdef", 4), "abcd");
});
